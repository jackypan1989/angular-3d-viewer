'use strict';

angular.module('angular-3d-viewer', []);